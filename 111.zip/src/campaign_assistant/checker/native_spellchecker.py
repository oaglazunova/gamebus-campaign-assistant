# This file contains checker logic adapted from GameBusChecker:
# https://github.com/SergeAutexier/GameBusChecker
#
# Original work:
#   Author: Serge Autexier
#   Copyright: DFKI GmbH 2026
#   License: Apache License 2.0
#
# Modifications:
#   Refactored and extended for GameBus Campaign Assistant by Olga Glazunova, 2026.
#   Changes include native checker integration, issue normalization, defensive handling
#   of campaign-export edge cases, assistant-facing messages, and additional guidance.
#
# Unless otherwise stated, original code in this repository is licensed under MIT.
# The adapted GameBusChecker-derived portions remain subject to Apache License 2.0.


from __future__ import annotations

from collections.abc import Mapping
from pathlib import Path
from typing import Any

import pandas as pd

try:
    import language_tool_python
    from language_tool_python.utils import TextStatus, classify_matches
except ImportError:  # optional dependency for the disabled-by-default spellchecker
    language_tool_python = None
    TextStatus = None
    classify_matches = None

from campaign_assistant.checker.schema import Issue, SPELLCHECKER
from campaign_assistant.checker.table_utils import (
    _active_wave_ids,
    _challenge_index,
    _challenge_url,
    _clean_scalar,
    _get_table,
    _visualization_index,
)

KNOWN_WORDS = [
    "Newbie",
    "Rookie",
    "Expert",
    "Master",
    "Grandmaster",
    "Skilled",
    "Proficient",
    "Mini-Walks",
    "Unterarmstützer",
    "Plank",
    "Wall-Sit",
    "Joggen",
    "MIND",
    "kalziumreiche",
    "Freundlichkeits-Tagebuch",
    "Mikrobiota",
    "Steppin",
    "Up",
    "Joggingintervalle",
    "Wandsitzer",
    "Wandsitz",
]


def load_spellchecker_tables(file_path: str | Path) -> dict[str, pd.DataFrame]:
    return {
        "tasks": pd.read_excel(file_path, sheet_name="tasks"),
        "challenges": pd.read_excel(file_path, sheet_name="challenges"),
        "visualizations": pd.read_excel(file_path, sheet_name="visualizations"),
        "waves": pd.read_excel(file_path, sheet_name="waves"),
    }


def build_spellchecker_tool():
    if language_tool_python is None:
        raise RuntimeError("language_tool_python is not installed")

    errors: list[str] = []

    try:
        return language_tool_python.LanguageTool(
            language="de-DE",
            mother_tongue="de-DE",
            new_spellings=KNOWN_WORDS,
            remote_server="http://localhost:8081/",
        )
    except Exception as exc:
        errors.append(f"remote server unavailable: {exc}")

    try:
        return language_tool_python.LanguageTool(
            language="de-DE",
            mother_tongue="de-DE",
            new_spellings=KNOWN_WORDS,
        )
    except Exception as exc:
        errors.append(f"local LanguageTool unavailable: {exc}")

    raise RuntimeError("; ".join(errors) if errors else "LanguageTool is unavailable")


def _spellchecker_unavailable_result(reason: str) -> dict[str, Any]:
    return {
        "status": "Passed",
        "issues": [],
        "notes": [f"Spellchecker skipped: {reason}"],
    }


def _issue(
    *,
    challenge: Mapping[str, Any],
    visualization: Mapping[str, Any],
    active_wave_ids: set[Any],
    title: str,
    message: str,
) -> Issue:
    wave_id = _clean_scalar(visualization.get("wave"))

    return Issue(
        check=SPELLCHECKER,
        severity="low",
        active_wave=wave_id in active_wave_ids if wave_id is not None else False,
        visualization_id=_clean_scalar(visualization.get("id")),
        visualization=str(_clean_scalar(visualization.get("description")) or ""),
        challenge_id=_clean_scalar(challenge.get("id")),
        challenge=str(_clean_scalar(challenge.get("name")) or ""),
        wave_id=wave_id,
        title=title,
        message=message,
        url=_challenge_url(visualization, challenge),
    )


def check_text(tool, text: Any, text_type: str) -> tuple[bool, str | None]:
    try:
        if text is None or pd.isna(text):
            return True, f"{text_type} is empty."
    except Exception:
        pass

    text = str(text).strip()
    if not text:
        return True, f"{text_type} is empty."

    if classify_matches is None or TextStatus is None:
        raise RuntimeError("language_tool_python is not installed")

    matches = tool.check(text)
    status = classify_matches(matches)
    errormessage = None

    if status == TextStatus.FAULTY:
        correction = tool.correct(text)
        errormessage = f"{text_type} is faulty '{text}'. Proposed correction is \n'{correction}'"
    elif status == TextStatus.GARBAGE:
        errormessage = f"{text_type} is garbage '{text}', no correction can be proposed"

    return (errormessage is not None), errormessage


def run_native_spellchecker_tables(
    tables: Mapping[str, pd.DataFrame],
    now: pd.Timestamp | None = None,
    tool=None,
) -> dict[str, Any]:
    try:
        tasks_df = _get_table(tables, "tasks")
        challenges_df = _get_table(tables, "challenges")
        visualizations_df = _get_table(tables, "visualizations")
        waves_df = tables.get("waves", pd.DataFrame())

        tool = tool if tool is not None else build_spellchecker_tool()
        challenges = _challenge_index(challenges_df)
        visualizations = _visualization_index(visualizations_df)
        active_wave_ids = _active_wave_ids(waves_df, now=now)

        issues: list[Issue] = []

        for _, task_row in tasks_df.iterrows():
            task = task_row.to_dict()
            challenge = challenges.get(task.get("challenge"))
            if challenge is None:
                continue

            visualization = visualizations.get(challenge.get("visualizations"))
            if visualization is None:
                continue

            error, errormessage = check_text(tool, task.get("name"), "Name of task")
            if error and errormessage is not None:
                issues.append(
                    _issue(
                        challenge=challenge,
                        visualization=visualization,
                        active_wave_ids=active_wave_ids,
                        title="Task name needs review",
                        message=errormessage,
                    )
                )

        for _, challenge_row in challenges_df.iterrows():
            challenge = challenge_row.to_dict()
            visualization = visualizations.get(challenge.get("visualizations"))
            if visualization is None:
                continue

            error, errormessage = check_text(tool, challenge.get("name"), "Name of challenge")
            if error and errormessage is not None:
                issues.append(
                    _issue(
                        challenge=challenge,
                        visualization=visualization,
                        active_wave_ids=active_wave_ids,
                        # title="Challenge name needs review",
                        title="Level name needs review",
                        message=errormessage,
                    )
                )

        issues.sort(key=lambda item: (item.active_wave, item.challenge_id), reverse=True)

        return {
            "status": "Failed" if issues else "Passed",
            "issues": issues,
            "notes": [],
        }
    except Exception as exc:
        return _spellchecker_unavailable_result(str(exc))


def run_native_spellchecker_check(
    file_path: str | Path,
    now: pd.Timestamp | None = None,
) -> dict[str, Any]:
    tables = load_spellchecker_tables(file_path)
    return run_native_spellchecker_tables(tables, now=now)